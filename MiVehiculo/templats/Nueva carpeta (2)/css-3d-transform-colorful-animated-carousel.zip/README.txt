A Pen created at CodePen.io. You can find this one at http://codepen.io/edmundojr/pen/qdLWWx.

 That's quite a title, eh?

I did it all over again, and I liked this one a lot more than the other one (http://codepen.io/edmundojr/pen/eNPJVW).

What do you think?